/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       brandon                                                   */
/*    Created:      Wed Feb 23 2022                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include "cmath"
using namespace vex;
competition Competition;

double lDriveSpeed, rDriveSpeed, driveSpeed;

void pneumaticOut(){
  pnm.open();
}
void pneumaticIn(){
  pnm.close();
}
void usercontrol(void) {
Brain.Timer.reset();
int rumbleCount = 0;
while (1) {
// Warnings
 if (Brain.Timer.value() >= 69.5 && Brain.Timer.value() < 70.5 &&
     rumbleCount == 0) {
   ctrlr.rumble(".");
   rumbleCount = 1;
   /* Vibrate whene there are 35 seconds left in the match, to warn
     the driver that the 30 second endgame is about to begin. Stop
     contacting the opponents' platform and/or any robots and game/
     field elements that are in contact with the platform. */
 } else if (Brain.Timer.value() >= 74.5 && Brain.Timer.value() < 75.5 &&
            rumbleCount == 1) {
   ctrlr.rumble(".");
   rumbleCount = 2; /* The endgame has begun. */
 }
//Drivetrain D-Pad

//Turning forward while holding back, add if statements.
 if (ctrlr.Axis1.value() > 0 && ctrlr.Axis3.value()>0) {
   lDriveSpeed = (ctrlr.Axis3.value() + ctrlr.Axis1.value())/2;
   rDriveSpeed = (ctrlr.Axis3.value() - ctrlr.Axis1.value())/2;
  // lDriveSpeed += 2*((pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
  //         (ctrlr.Axis3.value() + ctrlr.Axis1.value()));
  // rDriveSpeed = 2*((pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
  //         (ctrlr.Axis3.value() + ctrlr.Axis1.value()));
  }
  else if (ctrlr.Axis1.value() < 0 && ctrlr.Axis3.value()>0) {
    lDriveSpeed = (ctrlr.Axis3.value() + ctrlr.Axis1.value())/2;
    rDriveSpeed = (ctrlr.Axis3.value() - ctrlr.Axis1.value())/2;


  // lDriveSpeed += 2*((pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
  //                 (ctrlr.Axis3.value() - ctrlr.Axis1.value()));
  // rDriveSpeed += 2*((pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
  //                 (ctrlr.Axis3.value() - ctrlr.Axis1.value()));

                  ctrlr.Screen.print(ctrlr.Axis1.value());
  }
  else if (ctrlr.Axis3.value() < 0 && ctrlr.Axis1.value() >0) {
    lDriveSpeed = (ctrlr.Axis3.value() - ctrlr.Axis1.value())/2;
    rDriveSpeed = -(ctrlr.Axis3.value() + ctrlr.Axis1.value())/2;
  // lDriveSpeed += (pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
  //         (ctrlr.Axis3.value() - ctrlr.Axis1.value());
  // rDriveSpeed = (pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
  //         (ctrlr.Axis3.value() + ctrlr.Axis1.value());
 }
 else if (ctrlr.Axis3.value() < 0 && ctrlr.Axis1.value() <0) {
   lDriveSpeed = (ctrlr.Axis3.value() - ctrlr.Axis1.value())/2;
   rDriveSpeed = (ctrlr.Axis3.value() + ctrlr.Axis1.value())/2;

  // lDriveSpeed += (pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
  //         (ctrlr.Axis3.value() + ctrlr.Axis1.value());
  // rDriveSpeed = (pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
  //         (ctrlr.Axis3.value() - ctrlr.Axis1.value());
 
  } else if (ctrlr.Axis3.value() > 0 || ctrlr.Axis3.value() < 0){
  lDriveSpeed += ctrlr.Axis3.value();
  rDriveSpeed += ctrlr.Axis3.value();
  }
 else if (ctrlr.Axis1.value() > 0) {
   lDriveSpeed += ctrlr.Axis1.value();
   rDriveSpeed += -(ctrlr.Axis1.value());
 }
 else if (ctrlr.Axis1.value() < 0) {
   lDriveSpeed += ctrlr.Axis1.value();
   rDriveSpeed += abs(ctrlr.Axis1.value());
 }
 else {
   rdrive.stop(brakeType::hold);
   ldrive.stop(brakeType::hold);
   lDriveSpeed = 0;
   rDriveSpeed = 0;
 }
 
// Drivetrain motor commands
 ldrive.spin(forward, lDriveSpeed, velocityUnits::pct);
 rdrive.spin(forward, rDriveSpeed, velocityUnits::pct);
 
  ctrlr.ButtonA.pressed(pneumaticOut);
  ctrlr.ButtonB.pressed(pneumaticIn);
}
 wait(20, msec);
}

void autonomous(void) {
  
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  

}
