using namespace vex;

extern brain Brain;
extern controller ctrlr;

extern motor rfm;
extern motor rmm;
extern motor rbm;
extern motor lfm;
extern motor lmm;
extern motor lbm;

extern pneumatics pnm; 

extern motor_group rdrive;
extern motor_group ldrive;
extern motor_group drive;
/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void);
