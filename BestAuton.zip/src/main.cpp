#include "vex.h"
using namespace vex;
competition Competition;
 
double lDriveSpeed, rDriveSpeed, dPadForwardBoost, dPadReverseBoost,
 dPadTurnRightBoost, dPadTurnLeftBoost;
 
void pre_auton(void) {
vexcodeInit();
lift.stop(brakeType::hold);
claw.stop(brakeType::hold);
con.stop(brakeType::hold);
drive.stop(brakeType::coast);
}

/* ------------------------- Tuning Values ------------------------- */
// Drive PID Tuning Values
double kP = 1.00;
double kI = 0.00; // doesn't seem to be necessary
double kD = 0.20;
 
// TurnPID Tuning Values
double turnkP = 0.500; //0.500
double turnkI = 0.000; //0.005
double turnkD = 0.000; //2.000

//PID Variables and Assigned Values
double targetPosition, robotPosition, targetAngle, robotAngle, error, turnError, prevError,
     prevTurnError, derivative, turnDerivative, totalError, totalTurnError, motorVoltage,
     turnMotorVoltage, maxSpeed;
 
//Booleans
bool enableDrivePID = false, resetPID = false, turning = false, driving = false;
 
//PID Code
int drivePID(){
  while (enableDrivePID) {
  //Reset Sensors and PID values
    if (resetPID){
      resetPID = false;
      robotPosition = 0;
      rfm.setPosition(0,deg);
      rbm.setPosition(0,deg);
      lfm.setPosition(0,deg);
      lbm.setPosition(0,deg);
      prevError = 0;
      prevTurnError = 0;
      totalError = 0;
      totalTurnError = 0;
      }
  //Driving
    if (driving == true) {
      //Potential (P)
        robotPosition = 4.1 / 2 * ((rfm.position(deg) + rbm.position(deg) + lfm.position(deg) + lbm.position(deg)) / 4) * (M_PI / 180) * 2 / 3;
        error = targetPosition - robotPosition;
      //Integral (I)
        if (fabs(error) < 10){
          totalError += error;
        }
      //Derivative (D)
        derivative = error - prevError;
      //Final equation
        motorVoltage = error * kP + totalError * kI + derivative * kD;
          if (motorVoltage > 12) {
            motorVoltage = 12;
          }
    } else {motorVoltage = 0;}
  //Angle Detection
    robotAngle = (37 / 36) * isnsr.rotation(deg);
  //Turning
    if (turning == true) {
    //Potential (P)
      turnError = robotAngle - targetAngle;
    //Integral (I) --- we don't need it now
      if(fabs(totalTurnError) < 3){
        totalTurnError += turnError;
      }
    //`Derivative (D)
      turnDerivative = turnError - prevTurnError;
    //Final equation (if using integral, add totalTurnError * turnkI)
      turnMotorVoltage = turnError * turnkP + totalTurnError * turnkI + turnDerivative * turnkD;
        if (turnMotorVoltage > 12) {
          turnMotorVoltage = 12;
        }
    } else {turnMotorVoltage = 0;}
  //Motor Instructions
    rdrive.spin(fwd, maxSpeed * (motorVoltage + turnMotorVoltage) / 12, voltageUnits::volt);
    ldrive.spin(fwd, maxSpeed * (motorVoltage - turnMotorVoltage) / 12, voltageUnits::volt);
  //Previous Error
    prevError = error;
    prevTurnError = turnError;
    task::sleep(20);
  }
return 1;
}

void robotDrive(double assignedTargetPosition, double timeOut, double assignedMaxSpeed) {
  turning = false;
  enableDrivePID = true;
  resetPID = true;
  task drivePIDTask(drivePID);
  targetPosition = assignedTargetPosition;
  maxSpeed = assignedMaxSpeed;
  Brain.resetTimer();
  driving = true;
  if(robotPosition >= targetPosition || Brain.timer(msec) >= timeOut){
      enableDrivePID = false;
      drive.stop(brakeType::hold);
      targetPosition = 0;
  }
    ctrlr.Screen.print(", ");
    ctrlr.Screen.print((rfm.position(deg) + rbm.position(deg)) / 2);
    Brain.Screen.print((rfm.position(deg) + rbm.position(deg)) / 2);
    Brain.Screen.newLine();
}

void robotTurn(double assignedTargetAngle, double timeOut, double assignedMaxSpeed) {
  driving = false;
  enableDrivePID = true;
  resetPID = true;
  task drivePIDTask(drivePID);
  targetAngle = assignedTargetAngle;
  maxSpeed = assignedMaxSpeed;
  Brain.resetTimer();
  turning = true;
    if (Brain.timer(msec) >= timeOut){
      enableDrivePID = false;
      drive.stop(brakeType::brake);
      targetAngle = 0;
    }
    ctrlr.Screen.print(", ");
    ctrlr.Screen.print(robotAngle);
    Brain.Screen.print(robotAngle);
    Brain.Screen.newLine();
}

void autonomous(void) {
  lift.spin(fwd, 100, velocityUnits::pct);
  wait(400, msec);
  lift.spin(reverse, 100, velocityUnits::pct);
  waitUntil(liftStopperLower.pressing());
  lift.stop(brakeType::brake);
  robotDrive(55, 1000, 100);
  wait(150, msec);
  claw.spin(fwd, 100, velocityUnits::pct);
  wait(100, msec);
  lift.spin(fwd, 100, velocityUnits::pct);
  waitUntil(liftStopperUpper.pressing());
  lift.stop(brakeType::hold);

}

void usercontrol(void) {
enableDrivePID=false;
Brain.Timer.reset();
int rumbleCount = 0;
while (1) {
// Warnings
 if (Brain.Timer.value() >= 69.5 && Brain.Timer.value() < 70.5 &&
     rumbleCount == 0) {
   ctrlr.rumble(".");
   rumbleCount = 1;
   /* Vibrate whene there are 35 seconds left in the match, to warn
     the driver that the 30 second endgame is about to begin. Stop
     contacting the opponents' platform and/or any robots and game/
     field elements that are in contact with the platform. */
 } else if (Brain.Timer.value() >= 74.5 && Brain.Timer.value() < 75.5 &&
            rumbleCount == 1) {
   ctrlr.rumble(".");
   rumbleCount = 2; /* The endgame has begun. */
 }
//Drivetrain D-Pad
 if (ctrlr.ButtonUp.pressing()) {
   dPadForwardBoost = 25;
 } else if (ctrlr.ButtonDown.pressing()) {
   dPadReverseBoost = 25;
 } else {
   dPadForwardBoost = 0;
   dPadReverseBoost = 0;
 }
 if (ctrlr.ButtonRight.pressing()) {
   dPadTurnRightBoost = 12.5;
 } else if (ctrlr.ButtonLeft.pressing()) {
   dPadTurnLeftBoost = 12.5;
 } else {
   dPadTurnRightBoost = 0;
   dPadTurnLeftBoost = 0;
 }
 lDriveSpeed = dPadForwardBoost + dPadTurnRightBoost - dPadTurnLeftBoost - dPadReverseBoost;
 rDriveSpeed = dPadForwardBoost - dPadTurnRightBoost + dPadTurnLeftBoost - dPadReverseBoost;
//Turning forward while holding back, add if statements.
 if (ctrlr.Axis1.value() > 0 && ctrlr.Axis3.value()>0) {
  lDriveSpeed += 2*((pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
          (ctrlr.Axis3.value() + ctrlr.Axis1.value()));
  rDriveSpeed = 2*((pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
          (ctrlr.Axis3.value() + ctrlr.Axis1.value()));
  }
  else if (ctrlr.Axis1.value() < 0 && ctrlr.Axis3.value()>0) {
  lDriveSpeed += 2*((pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
                  (ctrlr.Axis3.value() - ctrlr.Axis1.value()));
  rDriveSpeed += 2*((pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
                  (ctrlr.Axis3.value() - ctrlr.Axis1.value()));
  }
  else if (ctrlr.Axis3.value() < 0 && ctrlr.Axis1.value() >0) {
  lDriveSpeed += (pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
          (ctrlr.Axis3.value() - ctrlr.Axis1.value());
  rDriveSpeed = (pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
          (ctrlr.Axis3.value() - ctrlr.Axis1.value());
 }
 else if (ctrlr.Axis3.value() < 0 && ctrlr.Axis1.value() <0) {
  lDriveSpeed += (pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
          (ctrlr.Axis3.value() + ctrlr.Axis1.value());
  rDriveSpeed = (pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
          (ctrlr.Axis3.value() + ctrlr.Axis1.value());
 
  } else if (ctrlr.Axis3.value() > 0 || ctrlr.Axis3.value() < 0){
  lDriveSpeed += ctrlr.Axis3.value();
  rDriveSpeed += ctrlr.Axis3.value();
  }
 else if (ctrlr.Axis1.value() > 0) {
   lDriveSpeed += ctrlr.Axis1.value();
   rDriveSpeed += -(ctrlr.Axis1.value());
 }
 else if (ctrlr.Axis1.value() < 0) {
   lDriveSpeed += ctrlr.Axis1.value();
   rDriveSpeed += abs(ctrlr.Axis1.value());
 }
 else {
   drive.stop();
 }
// Drivetrain motor commands
 ldrive.spin(forward, lDriveSpeed, velocityUnits::pct);
 rdrive.spin(forward, rDriveSpeed, velocityUnits::pct);
// Ring Conveyor Belt
  con.spin(fwd, 12, voltageUnits::volt);
 /*if (ctrlr.ButtonA.pressing()) {
   con.spin(forward, 9, voltageUnits::volt);
 } else if (ctrlr.ButtonY.pressing()) {
   con.spin(reverse, 12, voltageUnits::volt);
 } else {con.stop(brakeType::brake);}
 */

// Lift
 if (ctrlr.ButtonR1.pressing() && liftStopperUpper.pressing()) {
   lift.stop(brakeType::hold);
 } else if (ctrlr.ButtonR1.pressing()) {
   lift.spin(forward, 12, voltageUnits::volt);
 } else if(ctrlr.ButtonR2.pressing() && liftStopperLower.pressing()) {
   lift.stop(brakeType::hold);
 } else if (ctrlr.ButtonR2.pressing()) {
   lift.spin(reverse, 12, voltageUnits::volt);
 } else if(ctrlr.ButtonX.pressing() && liftStopperUpper.pressing()) {
   lift.stop(brakeType::hold);
 } else if (ctrlr.ButtonX.pressing()) {
   lift.spin(forward, 5, voltageUnits::volt);
 } else if (ctrlr.ButtonB.pressing() && liftStopperLower.pressing()) {
   lift.stop(brakeType::hold);
 } else if (ctrlr.ButtonB.pressing()) {
   lift.spin(reverse, 4, voltageUnits::volt);
 } else {lift.stop(brakeType::brake);}
   
 
// Claw
 if (ctrlr.ButtonL2.pressing()) {
   claw.spin(forward, 12, voltageUnits::volt);
 } else if (ctrlr.ButtonL1.pressing()) {
   claw.spin(reverse, 12, voltageUnits::volt);
 } else {
   claw.stop(brakeType::hold);
 }
 wait(20, msec);
}
}
 
int main() {
pre_auton();
Competition.autonomous(autonomous);
pre_auton();
Competition.drivercontrol(usercontrol);
pre_auton();
while (true) {
 wait(100, msec);
}
}