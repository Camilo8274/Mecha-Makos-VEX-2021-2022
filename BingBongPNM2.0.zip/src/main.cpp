#include "vex.h"
#include "cmath"
using namespace vex;
competition Competition;
 


double lDriveSpeed, rDriveSpeed, dPadForwardBoost, dPadReverseBoost,
      dPadTurnRightBoost, dPadTurnLeftBoost, driveSpeed;

//PID Equations

double kP = 1.00;
double kI = 0.00; // doesn't seem to be necessary
double kD = 0.20;
 
// TurnPID Tuning Values
double turnkP = 0.500; //0.500
double turnkI = 0.000; //0.005
double turnkD = 0.000; //2.000

//PID Variables and Assigned Values
//X-VALUES
double targetPositionX, robotPositionX, errorX, prevErrorX, derivativeX, totalErrorX,  
      motorVoltage,maxSpeed;

//Y-VALUES
double targetPositionY,robotPositionY, errorY, prevErrorY, derivativeY,  totalErrorY;

//DISTANCE-VALUES
double targetDistance, robotDistance, errorDistance, prevErrorDistance, derivativeDistance, totalErrorDistance;

//TURN VALUES
double targetAngle, robotAngle,turnError, prevTurnError,turnDerivative,totalTurnError,turnMotorVoltage;
 
//Booleans
bool enableDrivePID = false, resetPID = false, turning = false, driving = false;
 
//PID Code
int drivePID(){
  while (enableDrivePID) {
  //Reset Sensors and PID values
    if (resetPID){
      resetPID = false;
      robotPositionX = 0;
      robotPositionY = 0;
      rfm.setPosition(0,deg);
      rbm.setPosition(0,deg);
      lfm.setPosition(0,deg);
      lbm.setPosition(0,deg);
      prevErrorX = 0;
      prevErrorY = 0;
      prevTurnError = 0;
      totalErrorX = 0;
      totalErrorY = 0;
      totalTurnError = 0;
      }
  //Driving go vrooooom
    if (driving == true) {
      //Potential (P)
        robotPositionX = GPS.xPosition(mm);
        robotPositionY = GPS.yPosition(mm);
        robotDistance = sqrt(exp2(GPS.xPosition(mm)) + exp2(GPS.yPosition(mm)));
        //4.1 / 2 * ((rfm.position(deg) + rbm.position(deg) + lfm.position(deg) + lbm.position(deg)) / 4) * (M_PI / 180) * 2 / 3;
        errorX = targetPositionX - robotPositionX;
        errorY = targetPositionY - robotPositionY;
        errorDistance = sqrt(exp2(errorX) + exp2(errorY));
      //Integral (I)
        if (fabs(errorX) < 10){
          totalErrorX += errorX;
        }
        if (fabs(errorY) < 10){
          totalErrorY += errorY;
        }
        if (fabs(errorDistance) < 10){
          totalErrorDistance += errorDistance;
        }
      //Derivative (D)
        derivativeX = errorX - prevErrorX;
        derivativeY = errorY - prevErrorY;
        derivativeDistance = errorDistance - prevErrorDistance;
      //Final equation
        motorVoltage = errorDistance * kP + totalErrorDistance * kI + derivativeDistance * kD;
          if (motorVoltage > 12) {
            motorVoltage = 12;
          }
    } else {motorVoltage = 0;}
  //Angle Detection
    robotAngle = (37 / 36) * isnsr.rotation(deg);
  //Turning
    if (turning == true) {
    //Potential (P)
      turnError = robotAngle - targetAngle;
    //Integral (I) --- we don't need it now
      if(fabs(totalTurnError) < 3){
        totalTurnError += turnError;
      }
    //`Derivative (D)
      turnDerivative = turnError - prevTurnError;
    //Final equation (if using integral, add totalTurnError * turnkI)
      turnMotorVoltage = turnError * turnkP + totalTurnError * turnkI + turnDerivative * turnkD;
        if (turnMotorVoltage > 12) {
          turnMotorVoltage = 12;
        }
    } else {turnMotorVoltage = 0;}
  //Motor Instructions
    rdrive.spin(fwd, maxSpeed * (motorVoltage + turnMotorVoltage) / 12, voltageUnits::volt);
    ldrive.spin(fwd, maxSpeed * (motorVoltage - turnMotorVoltage) / 12, voltageUnits::volt);
  //Previous Error
    prevErrorX = errorX;
    prevErrorY = errorY;
    prevErrorDistance = errorDistance;
    prevTurnError = turnError;
    task::sleep(20);
  }
return 1;
}

void clawOut(){
  clawLeft.open();
  clawRight.open();
}

void clawIn(){
  clawLeft.close();
  wait(10, msec);
  clawRight.close();
}

void pre_auton(void) {
vexcodeInit();
lift.stop(brakeType::hold);

con.stop(brakeType::hold);
drive.stop(brakeType::coast);
}


void autonomous(void) {
  Brain.resetTimer();
  drive.spin(fwd, 100, voltageUnits::volt);
  con.spin(forward, 100, velocityUnits::pct);
  wait(200, msec);
  con.stop(coast);
  wait(200, msec);
  // waitUntil(liftStopperLower.pressing() || Brain.timer(msec) >= 1100);
  waitUntil(Brain.timer(msec) >= 1150);
  clawOut();
  wait(100, msec);
  drive.spinFor(reverse, 950, msec, 100, velocityUnits::pct); //1500
  // wait(1650, msec);
  wait(400,msec);
  while (std::abs(isnsr.rotation(degrees)) < 100) {
   driveSpeed = 60 * ((100 - (std::abs(isnsr.rotation(degrees)))) / 100) + 3;
   rdrive.spin(directionType::fwd, driveSpeed, velocityUnits::pct);
   ldrive.spin(directionType::rev, driveSpeed, velocityUnits::pct);
   wait(20, msec);
  }
  clawIn();
  rdrive.stop();
  ldrive.stop();
  wait(100, msec);
  ctrlr.Screen.print(isnsr.rotation());
  drive.spin(reverse, 100, velocityUnits::pct); //50
  wait(300, msec);
  drive.stop();
  isnsr.resetRotation();
   while (std::abs(isnsr.rotation(degrees)) < 50) {
   driveSpeed = 60 * ((50 - (std::abs(isnsr.rotation(degrees)))) / 50) + 3;
   rdrive.spin(directionType::rev, driveSpeed, velocityUnits::pct);
   ldrive.spin(directionType::fwd, driveSpeed, velocityUnits::pct);
   wait(20, msec);
  }
  rdrive.stop();
  ldrive.stop();
  wait(100, msec);
  ctrlr.Screen.print(isnsr.rotation());
  drive.spin(reverse, 350, velocityUnits::pct); //50
  wait(100, msec);
  con.spin(fwd, 100, velocityUnits::pct);
  lift.spin(fwd, 100, velocityUnits::pct);
  wait(500, sec);
  lift.stop(brakeType::coast);
  wait(500, msec);
  lift.spin(reverse, 100, velocityUnits::pct);
  drive.stop();
  /*while (std::abs(isnsr.rotation(degrees)) < 85) { 
    driveSpeed = 60 * ((85 - (std::abs(isnsr.rotation(degrees)))) / 85) + 3;
    rdrive.spin(directionType::rev, driveSpeed, velocityUnits::pct);
    ldrive.spin(directionType::fwd, driveSpeed, velocityUnits::pct);
    wait(20, msec);
  }
  rdrive.stop();
  ldrive.stop();
  */
}

void usercontrol(void) {
Brain.Timer.reset();
int rumbleCount = 0;
while (1) {
// Warnings
 if (Brain.Timer.value() >= 69.5 && Brain.Timer.value() < 70.5 &&
     rumbleCount == 0) {
   ctrlr.rumble(".");
   rumbleCount = 1;
   /* Vibrate whene there are 35 seconds left in the match, to warn
     the driver that the 30 second endgame is about to begin. Stop
     contacting the opponents' platform and/or any robots and game/
     field elements that are in contact with the platform. */
 } else if (Brain.Timer.value() >= 74.5 && Brain.Timer.value() < 75.5 &&
            rumbleCount == 1) {
   ctrlr.rumble(".");
   rumbleCount = 2; /* The endgame has begun. */
 }
//Drivetrain D-Pad
 if (ctrlr.ButtonUp.pressing()) {
   dPadForwardBoost = 25;
 } else if (ctrlr.ButtonDown.pressing()) {
   dPadReverseBoost = 25;
 } else {
   dPadForwardBoost = 0;
   dPadReverseBoost = 0;
 }
 if (ctrlr.ButtonRight.pressing()) {
   dPadTurnRightBoost = 12.5;
 } else if (ctrlr.ButtonLeft.pressing()) {
   dPadTurnLeftBoost = 12.5;
 } else {
   dPadTurnRightBoost = 0;
   dPadTurnLeftBoost = 0;
 }
 lDriveSpeed = dPadForwardBoost + dPadTurnRightBoost - dPadTurnLeftBoost - dPadReverseBoost;
 rDriveSpeed = dPadForwardBoost - dPadTurnRightBoost + dPadTurnLeftBoost - dPadReverseBoost;
//Turning forward while holding back, add if statements.
 if (ctrlr.Axis1.value() > 0 && ctrlr.Axis3.value()>0) {
  lDriveSpeed += 2*((pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
          (ctrlr.Axis3.value() + ctrlr.Axis1.value()));
  rDriveSpeed = 2*((pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
          (ctrlr.Axis3.value() + ctrlr.Axis1.value()));
  }
  else if (ctrlr.Axis1.value() < 0 && ctrlr.Axis3.value()>0) {
  lDriveSpeed += 2*((pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
                  (ctrlr.Axis3.value() - ctrlr.Axis1.value()));
  rDriveSpeed += 2*((pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
                  (ctrlr.Axis3.value() - ctrlr.Axis1.value()));
  }
  else if (ctrlr.Axis3.value() < 0 && ctrlr.Axis1.value() >0) {
  lDriveSpeed += (pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
          (ctrlr.Axis3.value() - ctrlr.Axis1.value());
  rDriveSpeed = (pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
          (ctrlr.Axis3.value() - ctrlr.Axis1.value());
 }
 else if (ctrlr.Axis3.value() < 0 && ctrlr.Axis1.value() <0) {
  lDriveSpeed += (pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
          (ctrlr.Axis3.value() + ctrlr.Axis1.value());
  rDriveSpeed = (pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
          (ctrlr.Axis3.value() + ctrlr.Axis1.value());
 
  } else if (ctrlr.Axis3.value() > 0 || ctrlr.Axis3.value() < 0){
  lDriveSpeed += ctrlr.Axis3.value();
  rDriveSpeed += ctrlr.Axis3.value();
  }
 else if (ctrlr.Axis1.value() > 0) {
   lDriveSpeed += ctrlr.Axis1.value();
   rDriveSpeed += -(ctrlr.Axis1.value());
 }
 else if (ctrlr.Axis1.value() < 0) {
   lDriveSpeed += ctrlr.Axis1.value();
   rDriveSpeed += abs(ctrlr.Axis1.value());
 }
 else {
   drive.stop();
 }
// Drivetrain motor commands
 ldrive.spin(forward, lDriveSpeed, velocityUnits::pct);
 rdrive.spin(forward, rDriveSpeed, velocityUnits::pct);
// Ring Conveyor Belt
 if (ctrlr.ButtonA.pressing()) {
   con.spin(forward, 9, voltageUnits::volt);
 } else if (ctrlr.ButtonY.pressing()) {
   con.spin(reverse, 12, voltageUnits::volt);
 } else {con.stop(brakeType::brake);}

// Lift
 if (ctrlr.ButtonR1.pressing() && liftStopperUpper.pressing()) {
   lift.stop(brakeType::hold);
 } else if (ctrlr.ButtonR1.pressing()) {
   lift.spin(forward, 12, voltageUnits::volt);
 } else if(ctrlr.ButtonR2.pressing() && liftStopperLower.pressing()) {
   lift.stop(brakeType::hold);
 } else if (ctrlr.ButtonR2.pressing()) {
   lift.spin(reverse, 12, voltageUnits::volt);
 } else if(ctrlr.ButtonX.pressing() && liftStopperUpper.pressing()) {
   lift.stop(brakeType::hold);
 } else if (ctrlr.ButtonX.pressing()) {
   lift.spin(forward, 5, voltageUnits::volt);
 } else if (ctrlr.ButtonB.pressing() && liftStopperLower.pressing()) {
   lift.stop(brakeType::hold);
 } else if (ctrlr.ButtonB.pressing()) {
   lift.spin(reverse, 4, voltageUnits::volt);
 } else {lift.stop(brakeType::brake);}
   
 
// Claw
 ctrlr.ButtonL2.pressed(clawOut);
 ctrlr.ButtonL1.pressed(clawIn);
 wait(20, msec);
}
}
 
int main() {
pre_auton();
Competition.autonomous(autonomous);
pre_auton();
Competition.drivercontrol(usercontrol);
pre_auton();
while (true) {
 wait(100, msec);
}
}