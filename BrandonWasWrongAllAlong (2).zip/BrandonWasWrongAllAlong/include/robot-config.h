using namespace vex;

extern brain Brain;
extern controller ctrlr;

extern motor rfm;
extern motor rbm;
extern motor lfm;
extern motor lbm;
extern motor con;
extern motor rightFourBarMotor;
extern motor leftFourBarMotor;
extern motor claw;

extern inertial isnsr;

extern gps GPS;

extern limit liftStopperUpper;
extern limit liftStopperLower;

extern encoder rightEncoder;
extern encoder leftEncoder;

extern motor_group rdrive;
extern motor_group ldrive;
extern motor_group drive;
extern motor_group lift;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void);