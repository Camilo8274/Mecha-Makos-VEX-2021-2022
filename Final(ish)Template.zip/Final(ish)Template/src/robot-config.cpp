#include "vex.h"

using namespace vex;

// A global instance of brain used for printing to the V5 brain screen
brain Brain;
controller ctrlr = controller(primary);

motor rfm = motor(PORT6, ratio18_1, true);
motor rbm = motor(PORT7, ratio18_1, true);
motor lfm = motor(PORT16, ratio18_1, false);
motor lbm = motor(PORT17, ratio18_1, false);
motor con = motor(PORT5, ratio18_1, false);
motor rightFourBarMotor = motor(PORT10, ratio36_1, true);
motor leftFourBarMotor = motor(PORT19, ratio36_1, false);
motor claw = motor(PORT3, ratio36_1, false);

inertial isnsr = inertial(PORT20);

// gps GPS = gps(PORT13); // gps GPS = gps(PORT13, xOffset in mm, yOffset in mm, headingOffset in deg = 180);

limit liftStopperUpper = limit(Brain.ThreeWirePort.A);
limit liftStopperLower = limit(Brain.ThreeWirePort.B);

motor_group rdrive(rfm, rbm);
motor_group ldrive(lfm, lbm);
motor_group drive(rfm, rbm, lfm, lbm);
motor_group lift(rightFourBarMotor, leftFourBarMotor);

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void) {
  wait(50,msec);
  Brain.Screen.print("Device initialization...");
  //rightFourBarMotor.setPosition(starting angle, rotationUnits::deg);
  //leftFourBarMotor.setPosition(starting angle, rotationUnits::deg);
  Brain.Screen.setCursor(2, 1);
  // calibrate the drivetrain gyro
  wait(150, msec);
  isnsr.calibrate();
  Brain.Screen.print("Calibrating Inertial Sensor");
  // wait for the gyro calibration process to finish
  while (isnsr.isCalibrating()) {
    wait(25, msec);
  }
  Brain.Screen.setCursor(3, 1);
  Brain.Screen.print("Calibration Complete");
  wait (3, sec);
  // reset the screen now that the calibration is complete
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1,1);
  wait(50, msec);
  Brain.Screen.clearScreen();
}