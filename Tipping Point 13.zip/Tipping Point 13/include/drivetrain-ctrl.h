#include "vex.h"

extern bool runDrivetrainControl, getOntoPlatform, balancedOnPlatform;

extern double deltaX, deltaY, sigmaX, sigmaY, robotAngle, targetX, targetY,
    targetAngle, timeLimit, maxSpeed, initialX, initialY, X, Y, prevX, prevY,
    balancekP, balanceCount, lDriveSpeed, rDriveSpeed;

extern void driveTo(double assignedTargetX, double assignedTargetY,
                    double assignedTargetAngle, double assignedTimeLimit,
                    double assignedMaxSpeed),
    turnTo(double assignedTargetAngle, double assignedTimeLimit),
    turnTowardsPoint(double xCoordToFace, double yCoordToFace,
                     double assignedTimeLimit);

extern int positionTracking(), drivetrainAutonControl(), balanceOnPlatform(), drivetrainDriverControl();