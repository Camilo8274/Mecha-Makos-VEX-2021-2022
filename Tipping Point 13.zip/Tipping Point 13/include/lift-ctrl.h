#include "vex.h"

extern double liftMovementPower, rightFourBarMotorError, leftFourBarMotorError,
    avgError, targetLiftAngle, rLiftMovementPower, lLiftMovementPower;

extern int liftAutonControl();