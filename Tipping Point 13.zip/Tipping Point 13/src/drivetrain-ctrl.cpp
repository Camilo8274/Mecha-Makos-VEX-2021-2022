#include "drivetrain-ctrl.h"
#include "vex.h"

bool runDrivetrainControl, getOntoPlatform, balancedOnPlatform = false;

double deltaX, deltaY, sigmaX, sigmaY, robotAngle, targetX, targetY,
    targetAngle, timeLimit, maxSpeed, initialX = 0, initialY = 0, X, Y, prevX, prevY,
    xDistToTarget, yDistToTarget, hypotAngle, angleToTarget,
    balancekP = 1, balanceCount = 0, turnError = 0, turnPrevError = 0,
    turnIntegral = 0, turnDerivative = 0, turnPowerPID = 0, driveError = 0,
    prevDriveError = 0, driveIntegral = 0, driveDerivative = 0,
    drivePowerPID = 0;

/* ------------------ IMPORTANT: PID Tuning Values!!!!! ------------------ */

// Linear Driving
double drivekP = 1.5;
double drivekI = 0.02;
double drivekD = 10.0;

double driveMaxError = 0.1;
double driveIntegralBound = 1.5;

// Turning
double turnkP = 13.00;
double turnkI = 1.00;
double turnkD = 10.00;

double turnMaxError = 0.01;
double turnIntegralBound = 0.09;

// Functions

void driveTo(double assignedTargetX, double assignedTargetY,
             double assignedTargetAngle, double assignedTimeLimit,
             double assignedMaxSpeed) {
  targetX = assignedTargetX;
  targetY = assignedTargetY;
  targetAngle = assignedTargetAngle;
  runDrivetrainControl = true;
  timeLimit = assignedTimeLimit;
  Brain.resetTimer();
  maxSpeed = assignedMaxSpeed;
}

void turnTo(double assignedTargetAngle, double assignedTimeLimit) {
  targetAngle = assignedTargetAngle;
  targetX = sigmaX;
  targetY = sigmaY;
  runDrivetrainControl = true;
  timeLimit = assignedTimeLimit;
  Brain.resetTimer();
}

void turnTowardsPoint(double xCoordToFace, double yCoordToFace,
                      double assignedTimeLimit) {
  targetAngle = atan2(yCoordToFace - sigmaY, xCoordToFace - sigmaX);
  if (targetAngle < 0) {
    targetAngle = 2 * M_PI - fabs(targetAngle);
  }
  targetX = sigmaX;
  targetY = sigmaY;
  runDrivetrainControl = true;
  timeLimit = assignedTimeLimit;
  Brain.resetTimer();
}

int positionTracking() {
  X = initialX;
  Y = initialY;
  while (1) {
    robotAngle = (180 - isnsr.heading(deg)) * M_PI /
                 180; // IMPORTANT!! We set the robot angle to 180 at the start
                      // of the match
    X = sin(robotAngle) * (4.1 * M_PI * 900 *
                           ((rbm.position(rotationUnits::raw) +
                             lbm.position(rotationUnits::raw)) /
                            2));
    Y = cos(robotAngle) * (4.1 * M_PI * 900 *
                           ((rbm.position(rotationUnits::raw) +
                             lbm.position(rotationUnits::raw)) /
                            2));
    deltaX = X - prevX;
    deltaY = Y - prevY;
    prevX = X;
    prevY = Y;
    sigmaX += deltaX;
    sigmaY += deltaY;
    wait(10, msec);
  }
  return 1;
}

void drivePID() {

  // Error is equal to the total distance away from the target (uses distance
  // formula with current position and target location)
  driveError = sqrt(pow((targetX - sigmaX), 2) + pow((targetY - sigmaY), 2));

  // only use integral if close enough to target
  if (fabs(driveError) < driveIntegralBound) {
    driveIntegral += driveError;
  } else {
    driveIntegral = 0;
  }

  // reset integral if we pass the target
  if (driveError * prevDriveError < 0) {
    driveIntegral = 0;
  }

  driveDerivative = driveError - prevDriveError;

  prevDriveError = driveError;

  drivePowerPID = (driveError * drivekP + driveIntegral * drivekI +
                   driveDerivative * drivekD);

  // Limit power output to 12V
  if (drivePowerPID > 12) {
    drivePowerPID = 12;
  }
  drivePowerPID = drivePowerPID * maxSpeed / 100;
  if (fabs(driveError) < driveMaxError) {
    drivePowerPID = 0;
  }
}

void turnPID() {

  // Error is equal to the difference between the current facing direction and
  // the target direction
  turnError = targetAngle - robotAngle;

  if (fabs(turnError) > M_PI) {
    turnError = fabs(2 * M_PI - turnError) - (turnError / fabs(turnError));
  }

  // only use integral if close enough to target
  if (fabs(turnError) < turnIntegralBound) {
    turnIntegral += turnError;
  } else {
    turnIntegral = 0;
  }

  // reset integral if we pass the target
  if (turnError * turnPrevError < 0) {
    turnIntegral = 0;
  }

  turnDerivative = turnError - turnPrevError;

  turnPrevError = turnError;

  turnPowerPID =
      (turnError * turnkP + turnIntegral * turnkI + turnDerivative * turnkD);

  // Limit power output to 12V
  if (turnPowerPID > 12) {
    turnPowerPID = 12;
  }

  if (fabs(turnError) < turnMaxError) {
    turnPowerPID = 0;
  }
   Brain.Screen.setCursor(3,2);
      Brain.Screen.print("drive error: %f", driveError);

      Brain.Screen.setCursor(5,2);
      Brain.Screen.print("turn error: %f", turnError);

      Brain.Screen.setCursor(7,2);
      Brain.Screen.print("turnPID power: %f", drivePowerPID);
}

/* CHASSIS CONTROL TASK */
int drivetrainAutonControl() {

  // loop to constantly execute chassis commands
  while (1) {
    if (runDrivetrainControl) {
      // Distances to target on each axis
      xDistToTarget = targetX - X;
      yDistToTarget = targetY - Y;

      // Angle of hypotenuse
      hypotAngle = atan2(yDistToTarget, xDistToTarget);

      if (hypotAngle < 0) {
        hypotAngle += 2 * M_PI;
      }

      // The angle the robot needs to turn relative to its forward direction in
      // order to go toward the target
      angleToTarget = hypotAngle - robotAngle + M_PI_2;

      if (angleToTarget > 2 * M_PI) {
        angleToTarget -= 2 * M_PI;
      } else if (angleToTarget < 0) {
        angleToTarget += 2 * M_PI;
      }

      // get PID values for driving and turning
      drivePID();
      turnPID();

      if (fabs(fabs(robotAngle) - fabs(angleToTarget)) > 2) {
        drivePowerPID = 0;
      }
      // Set power for each motor
      double lPower = (drivePowerPID * (1 - 2 * sin(turnError)) + turnPowerPID);
      double rPower = (drivePowerPID * (1 + 2 * sin(turnError)) - turnPowerPID);
      // Limit motor power to 12 volts
      if (lPower > 12) {
        lPower = 12;
      } else if (lPower < -12) {
        lPower = -12;
      }
      if (rPower > 12) {
        rPower = 12;
      } else if (lPower < -12) {
        lPower = -12;
      }
      // Drivetrain commands
      ldrive.spin(directionType::fwd, lPower * maxSpeed / 100,
                  voltageUnits::volt);
      rdrive.spin(directionType::fwd, rPower * maxSpeed / 100,
                  voltageUnits::volt);

      if (fabs(driveError) < 0.1 && fabs(turnError) < 0.003) {
        runDrivetrainControl = false;
      }
      // Timeout
      if (Brain.timer(timeUnits::msec) > timeLimit) {
        runDrivetrainControl = false;
      }
    }
    // Brakes
    else {
      drive.stop(brakeType::hold);
    }
    task::sleep(20);
  }
  return 1;
}

int balanceOnPlatform() {
  while (1) {
    if (getOntoPlatform == true && isnsr.pitch() > -5) {
      drive.spin(forward, 100, velocityUnits::pct);
      waitUntil(isnsr.pitch() <= -7.5);
      balanceCount = 1;
    } else if (balanceCount > 0) {
      double balanceError, balanceDrivetrainSpeed;
      balanceError = isnsr.pitch();
      balanceDrivetrainSpeed = -(balancekP * balanceError);
      drive.spin(forward, balanceDrivetrainSpeed, velocityUnits::pct);
      if (fabs(isnsr.pitch()) <= 1) {
        balanceCount = 2;
      }
    } else if (balanceCount == 2 && fabs(isnsr.pitch()) <= 2) {
      drive.stop(brakeType::hold);
      getOntoPlatform = false;
      balancedOnPlatform = true;
    }
    wait(10, msec);
  }
  return 1;
}