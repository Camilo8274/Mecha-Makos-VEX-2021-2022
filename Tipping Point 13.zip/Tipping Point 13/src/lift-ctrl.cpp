#include "vex.h"
#include "lift-ctrl.h"

double liftMovementPower = 12, rightFourBarMotorError, leftFourBarMotorError, avgError,
         targetLiftAngle, rLiftMovementPower, lLiftMovementPower;

int liftAutonControl() {
  while (1) {
    // targetLiftAngle = asin((targetLiftHeight - 16.75) / 16) + 90;
    rightFourBarMotorError = targetLiftAngle - (rightFourBarMotor.position(deg) / 7);
    leftFourBarMotorError = targetLiftAngle - (leftFourBarMotor.position(deg) / 7);
    avgError = rightFourBarMotorError + leftFourBarMotorError / 2;
    rLiftMovementPower = liftMovementPower * leftFourBarMotorError / rightFourBarMotorError;
    lLiftMovementPower = liftMovementPower * rightFourBarMotorError / leftFourBarMotorError;
    if (fabs(avgError) > 5) {
      if (liftStopper.pressing() && targetLiftAngle > avgError) {
        liftMovementPower = 0;
        lift.stop(brakeType::hold);
      } else {
        rightFourBarMotor.spin(forward, rLiftMovementPower, voltageUnits::volt);
        leftFourBarMotor.spin(forward, lLiftMovementPower, voltageUnits::volt);
      }
    }
    wait(20, msec);
  }
  return 1;
}