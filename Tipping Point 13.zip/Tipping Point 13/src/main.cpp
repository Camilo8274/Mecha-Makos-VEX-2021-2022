#include "drivetrain-ctrl.h"
#include "lift-ctrl.h"
#include "vex.h"

using namespace vex;

competition Competition;

double lDriveSpeed, rDriveSpeed, dPadForwardBoost, dPadReverseBoost,
    dPadTurnRightBoost, dPadTurnLeftBoost;

task balanceOnPlatformTask;
task liftControlTask;
task drivetrainAutonControlTask;
// task hookDriverControlTask;

void pre_auton(void) {
  vexcodeInit();
  lift.stop(brakeType::hold);
  drive.stop(brakeType::hold);
}

void autonRun() {

  //make lift go uppy for a lil bit then down for a lil bit

  drive.spin(forward, 100, velocityUnits::pct);
  wait(500, timeUnits::msec);
  drive.stop();

  //claw.spin(reverse, ??)

  lift.spin(forward, 12, voltageUnits::volt);
  
  waitUntil(liftStopper.pressing());
  
  lift.stop(brakeType::hold);
  
  driveTo(-24, 24, 146.31, 5, 50);
  
  con.spinFor(forward, 5, sec, 100, velocityUnits::pct);

}

void autonomous(void) {
  task drivetrainAutonControlTask(drivetrainAutonControl);
  autonRun();  
}

void usercontrol(void) {
  Brain.Timer.reset();
  int rumbleCount = 0;
  while (1) {
   // Warnings
    if (Brain.Timer.value() >= 69.5 && Brain.Timer.value() < 70.5 &&
        rumbleCount == 0) {
      ctrlr.rumble(".");
      rumbleCount = 1;
      /* Vibrate whene there are 35 seconds left in the match, to warn
        the driver that the 30 second endgame is about to begin. Stop
        contacting the opponents' platform and/or any robots and game/
        field elements that are in contact with the platform. */
    } else if (Brain.Timer.value() >= 74.5 && Brain.Timer.value() < 75.5 &&
               rumbleCount == 1) {
      ctrlr.rumble(".");
      rumbleCount = 2; /* The endgame has begun. */
    }
   //Drivetrain D-Pad
    if (ctrlr.ButtonUp.pressing()) {
      dPadForwardBoost = 25;
    } else {
      dPadForwardBoost = 0;
    }
    if (ctrlr.ButtonDown.pressing()) {
      dPadReverseBoost = 25;
    } else {
      dPadReverseBoost = 0;
    }
    if (ctrlr.ButtonRight.pressing()) {
      dPadTurnRightBoost = 12.5;
    } else {
      dPadTurnRightBoost = 0;
    }
    if (ctrlr.ButtonLeft.pressing()) {
      dPadTurnLeftBoost = 12.5;
    } else {
      dPadTurnLeftBoost = 0;
    }
    lDriveSpeed = dPadForwardBoost + dPadTurnRightBoost - dPadTurnLeftBoost - dPadReverseBoost;
    rDriveSpeed = dPadForwardBoost - dPadTurnRightBoost + dPadTurnLeftBoost - dPadReverseBoost;
    if (ctrlr.Axis1.value() > 0) {
      lDriveSpeed += (pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
              (ctrlr.Axis3.value() + ctrlr.Axis1.value());
      rDriveSpeed = (pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
              (ctrlr.Axis3.value() + ctrlr.Axis1.value());
    } else if (ctrlr.Axis1.value() < 0) {
      lDriveSpeed += (pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
                      (ctrlr.Axis3.value() - ctrlr.Axis1.value());
      rDriveSpeed += (pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
                      (ctrlr.Axis3.value() - ctrlr.Axis1.value());
    } else {
      lDriveSpeed += ctrlr.Axis3.value();
      rDriveSpeed += ctrlr.Axis3.value();
    }
    // Drivetrain motor commands
    ldrive.spin(forward, lDriveSpeed, velocityUnits::pct);
    rdrive.spin(forward, rDriveSpeed, velocityUnits::pct);
    // Ring Conveyor Belt
    if (ctrlr.ButtonL1.pressing()) {
      con.spin(forward, 9, voltageUnits::volt);
    } else if (ctrlr.ButtonL2.pressing()) {
      con.spin(reverse, 12, voltageUnits::volt);
    } else {con.stop(brakeType::brake);}
    // Lift
    if (ctrlr.ButtonR1.pressing() && liftStopper.pressing()) {
      lift.stop(brakeType::hold);
    } else if (ctrlr.ButtonR1.pressing()) {
      lift.spin(forward, 8, voltageUnits::volt);
    } else if (ctrlr.ButtonR2.pressing()) {
      lift.spin(reverse, 6, voltageUnits::volt);
    } else {lift.stop(brakeType::brake);}
    // Claw
    if (ctrlr.ButtonX.pressing()) {
      claw.spin(forward, 6, voltageUnits::volt);
    } else if (ctrlr.ButtonB.pressing()) {
      claw.spin(reverse, 6, voltageUnits::volt);
    } else {
      claw.stop(brakeType::hold);
    }
    // Auto-Balancing
    if (ctrlr.ButtonL1.pressing() && ctrlr.ButtonL2.pressing() &&
        ctrlr.ButtonX.pressing()) {
      task balanceOnPlatformTask(balanceOnPlatform);
      Brain.Timer.reset();
      ctrlr.rumble("-");
      getOntoPlatform = true;
      waitUntil(balancedOnPlatform = true or Brain.Timer.value() >= 7);
    }
    wait(20, msec);
  }
}

int main() {
  pre_auton();
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  while (true) {
    wait(100, msec);
  }
}