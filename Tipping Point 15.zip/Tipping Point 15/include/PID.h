#include "vex.h"

extern bool runDrivetrainControl;

extern double robotAngle, targetAngle, timeLimit, maxSpeed, X, Y, prevX, prevY, lDriveSpeed, rDriveSpeed;

extern void driveTo(double assignedTargetDistance, double assignedTimeLimit, double assignedMaxSpeed);
extern void turnTo(double assignedTargetAngle, double assignedTimeLimit);

extern int positionTracking(), drivetrainAutonControl();