#include "vex.h"

using namespace vex;

competition Competition;

double lDriveSpeed, rDriveSpeed, dPadForwardBoost, dPadReverseBoost,
    dPadTurnRightBoost, dPadTurnLeftBoost;

// task hookDriverControlTask;

void pre_auton(void) {
  vexcodeInit();
  lift.stop(brakeType::hold);
  claw.stop(brakeType::hold);
  ldrive.stop(brakeType::brake);
  rdrive.stop(brakeType::brake);
  con.stop(brakeType::hold);
}

//Defined Values
 double kP = 0.50;
 double kI = 0.00; // doesn't seem to be necessary
 double kD = 0.00; // doesn't seem to be necessary

 double turnkP = 0.01;
 double turnkI = 0.00; //0.01
 double turnkD = 0.00; //1.3

//Variables and Assigned Values
 double targetPosition, robotPosition, targetAngle, robotAngle, error, turnError, prevError,
        prevTurnError, derivative, turnDerivative, totalError, totalTurnError;

//Boolin
 bool enableDrivePID = true;
 bool resetDriveSensors = false;

//PID Code
 int drivePID(){
  while (enableDrivePID) {
   //Reset
    if (resetDriveSensors){
      resetDriveSensors = false;
      rfm.setPosition(0,deg);
      rbm.setPosition(0,deg);
      lfm.setPosition(0,deg);
      lbm.setPosition(0,deg);
      isnsr.setRotation(0,deg);
     }
   //Driving
     //Potential (P)
      robotPosition = ((rfm.position(deg)+rbm.position(deg)+lfm.position(deg)+lbm.position(deg))/4);
      error=targetPosition - robotPosition;
     //Integral (I)
      if (fabs(error) < 10){
        totalError += error;
      }
     //Derivative (D)
      derivative = error - prevError;
     //Final equation
      double motorVoltage = error * kP + totalError * kI + derivative * kD;
   //Angle Detection
    robotAngle = (37/36)*isnsr.rotation(deg);
    int inertialSensor = robotAngle;
   //Turning
     //Potential (P)
      turnError = inertialSensor - targetAngle;
     //Integral (I) --- we don't need it now
      if(fabs(totalTurnError) < 3){
        totalTurnError += turnError;
      }
     //Derivative (D)
      turnDerivative = turnError - prevTurnError;
     //Final equation (if using integral, add totalTurnError * turnkI)
      double turnMotorVoltage = turnError * turnkP + totalTurnError * turnkI + turnDerivative * turnkD;
     //Motor Instructions
      rdrive.spin(fwd, motorVoltage - turnMotorVoltage, voltageUnits::volt);
      ldrive.spin(fwd, motorVoltage + turnMotorVoltage, voltageUnits::volt);
     //Previous Error
     prevTurnError = turnError;
     task::sleep(20);
   }
   return 1;
  }

void autonomous(void) {
//Turn Right
 task Onion_JimmyTurnRight(drivePID);
 repeat(8){
 resetDriveSensors=true;
 targetAngle=0;
 targetPosition = 500;
 wait(1.5,sec);
 ctrlr.Screen.clearLine();
 ctrlr.Screen.print(robotPosition);
 Brain.Screen.print(robotPosition);
 Brain.Screen.newLine();
 resetDriveSensors=true;
 targetAngle = 90;
 targetPosition=0;
 wait(2,sec);
 ctrlr.Screen.print(", ");
 ctrlr.Screen.print(robotAngle);
 Brain.Screen.print(robotAngle);
 Brain.Screen.newLine();
 }
 enableDrivePID=false;
}

void usercontrol(void) {
  enableDrivePID=false;
  Brain.Timer.reset();
  int rumbleCount = 0;
  while (1) {
   // Warnings
    if (Brain.Timer.value() >= 69.5 && Brain.Timer.value() < 70.5 &&
        rumbleCount == 0) {
      ctrlr.rumble(".");
      rumbleCount = 1;
      /* Vibrate whene there are 35 seconds left in the match, to warn
        the driver that the 30 second endgame is about to begin. Stop
        contacting the opponents' platform and/or any robots and game/
        field elements that are in contact with the platform. */
    } else if (Brain.Timer.value() >= 74.5 && Brain.Timer.value() < 75.5 &&
               rumbleCount == 1) {
      ctrlr.rumble(".");
      rumbleCount = 2; /* The endgame has begun. */
    }
   //Drivetrain D-Pad
    if (ctrlr.ButtonUp.pressing()) {
      dPadForwardBoost = 25;
    } else {
      dPadForwardBoost = 0;
    }
    if (ctrlr.ButtonDown.pressing()) {
      dPadReverseBoost = 25;
    } else {
      dPadReverseBoost = 0;
    }
    if (ctrlr.ButtonRight.pressing()) {
      dPadTurnRightBoost = 12.5;
    } else {
      dPadTurnRightBoost = 0;
    }
    if (ctrlr.ButtonLeft.pressing()) {
      dPadTurnLeftBoost = 12.5;
    } else {
      dPadTurnLeftBoost = 0;
    }
    lDriveSpeed = dPadForwardBoost + dPadTurnRightBoost - dPadTurnLeftBoost - dPadReverseBoost;
    rDriveSpeed = dPadForwardBoost - dPadTurnRightBoost + dPadTurnLeftBoost - dPadReverseBoost;
    if (ctrlr.Axis1.value() > 0) {
      lDriveSpeed += (pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
              (ctrlr.Axis3.value() + ctrlr.Axis1.value());
      rDriveSpeed = (pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
              (ctrlr.Axis3.value() + ctrlr.Axis1.value());
    } else if (ctrlr.Axis1.value() < 0) {
      lDriveSpeed += (pow(ctrlr.Axis3.value(), 2) - pow(ctrlr.Axis1.value(), 2)) /
                      (ctrlr.Axis3.value() - ctrlr.Axis1.value());
      rDriveSpeed += (pow(ctrlr.Axis3.value(), 2) + pow(ctrlr.Axis1.value(), 2)) /
                      (ctrlr.Axis3.value() - ctrlr.Axis1.value());
    } else {
      lDriveSpeed += ctrlr.Axis3.value();
      rDriveSpeed += ctrlr.Axis3.value();
    }
    // Drivetrain motor commands
    ldrive.spin(forward, lDriveSpeed, velocityUnits::pct);
    rdrive.spin(forward, rDriveSpeed, velocityUnits::pct);
    // Ring Conveyor Belt
    if (ctrlr.ButtonL1.pressing()) {
      con.spin(forward, 9, voltageUnits::volt);
    } else if (ctrlr.ButtonL2.pressing()) {
      con.spin(reverse, 12, voltageUnits::volt);
    } else {con.stop(brakeType::brake);}
    // Lift
    if (ctrlr.ButtonR1.pressing() && liftStopper.pressing()) {
      lift.stop(brakeType::hold);
    } else if (ctrlr.ButtonR1.pressing()) {
      lift.spin(forward, 8, voltageUnits::volt);
    } else if (ctrlr.ButtonR2.pressing()) {
      lift.spin(reverse, 6, voltageUnits::volt);
    } else {lift.stop(brakeType::brake);}
    // Claw
    if (ctrlr.ButtonX.pressing()) {
      claw.spin(forward, 6, voltageUnits::volt);
    } else if (ctrlr.ButtonB.pressing()) {
      claw.spin(reverse, 6, voltageUnits::volt);
    } else {
      claw.stop(brakeType::hold);
    }
    wait(20, msec);
  }
}

int main() {
  pre_auton();
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  while (true) {
    wait(100, msec);
  }
}